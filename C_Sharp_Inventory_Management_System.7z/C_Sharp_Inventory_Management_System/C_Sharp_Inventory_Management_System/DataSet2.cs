﻿namespace C_Sharp_Inventory_Management_System
{


    partial class DataSet2
    {
        partial class DataTable1DataTable
        {
        }
    }
}
